<section class="down-box" id="contact">
  <div class="contactSkills">
    <div class="contact-info">
      <div class="main-text">
        <h2 class="heading">Contact Me</h2>
        <span>get in touch with me</span>
      </div>
      <form action="code.php" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="input-box">
          <input type="text" name="first_name" id="name" placeholder="First Name" required />
          <input type="text" name="last_name" id="last-name" placeholder="Last Name" required />
        </div>
        <input type="email" name="email" id="email" placeholder="Email" required />
        <input type="number" name="phone" id="phone" placeholder="phone number" required />
        <textarea name="message" id="" placeholder="Message" rows="10" cols="30" required></textarea>
        </textarea>
        <div class="formBtn">
          <button type="submit" name="submit" class="btn">Send Message</button>
        </div>
      </form>
    </div>
    <div class="skills">
      <div class="container">
        <div class="skillBox">
          <div class="main-text">
            <h2 class="heading">My Skills</h2>
            <span>Let Me Help you</span>
          </div>
          <div class="skill-wrap">
            <div class="skill">
              <div class="outer-circle">
                <div class="inner-circle">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180px" height="180px">
                    <defs>
                      <linearGradient id="GradientColor">
                        <stop offset="0%" stop-color="#e91e63" />
                        <stop offset="100%" stop-color="#673ab7" />
                      </linearGradient>
                    </defs>
                    <circle cx="85" cy="85" r="75" stroke-linecap="round" />
                  </svg>
                  <h2 class="counter"><span data-target="90">0</span>%</h2>
                </div>
              </div>
              <div class="sk-title">HTML</div>
            </div>

            <div class="skill">
              <div class="outer-circle">
                <div class="inner-circle">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180px" height="180px">
                    <defs>
                      <linearGradient id="GradientColor">
                        <stop offset="0%" stop-color="#e91e63" />
                        <stop offset="100%" stop-color="#673ab7" />
                      </linearGradient>
                    </defs>
                    <circle cx="85" cy="85" r="75" stroke-linecap="round" />
                  </svg>
                  <h2 class="counter"><span data-target="75">0</span>%</h2>
                </div>
              </div>
              <div class="sk-title">CSS</div>
            </div>

            <div class="skill">
              <div class="outer-circle">
                <div class="inner-circle">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180px" height="180px">
                    <defs>
                      <linearGradient id="GradientColor">
                        <stop offset="0%" stop-color="#e91e63" />
                        <stop offset="100%" stop-color="#673ab7" />
                      </linearGradient>
                    </defs>
                    <circle cx="85" cy="85" r="75" stroke-linecap="round" />
                  </svg>
                  <h2 class="counter"><span data-target="60">0</span>%</h2>
                </div>
              </div>
              <div class="sk-title">JavaScript</div>
            </div>
            <div class="skill">
              <div class="outer-circle">
                <div class="inner-circle">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180px" height="180px">
                    <defs>
                      <linearGradient id="GradientColor">
                        <stop offset="0%" stop-color="#e91e63" />
                        <stop offset="100%" stop-color="#673ab7" />
                      </linearGradient>
                    </defs>
                    <circle cx="85" cy="85" r="75" stroke-linecap="round" />
                  </svg>
                  <h2 class="counter"><span data-target="70">0</span>%</h2>
                </div>
              </div>
              <div class="sk-title">Word Press</div>
            </div>
            <div class="skill">
              <div class="outer-circle">
                <div class="inner-circle">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180px" height="180px">
                    <defs>
                      <linearGradient id="GradientColor">
                        <stop offset="0%" stop-color="#e91e63" />
                        <stop offset="100%" stop-color="#673ab7" />
                      </linearGradient>
                    </defs>
                    <circle cx="85" cy="85" r="75" stroke-linecap="round" />
                  </svg>
                  <h2 class="counter"><span data-target="56">0</span>%</h2>
                </div>
              </div>
              <div class="sk-title">Tailwind CSS</div>
            </div>

            <div class="skill">
              <div class="outer-circle">
                <div class="inner-circle">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="180px" height="180px">
                    <defs>
                      <linearGradient id="GradientColor">
                        <stop offset="0%" stop-color="#e91e63" />
                        <stop offset="100%" stop-color="#673ab7" />
                      </linearGradient>
                    </defs>
                    <circle cx="85" cy="85" r="75" stroke-linecap="round" />
                  </svg>
                  <h2 class="counter"><span data-target="60">0</span>%</h2>
                </div>
              </div>
              <div class="sk-title">UI/UX Design</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>