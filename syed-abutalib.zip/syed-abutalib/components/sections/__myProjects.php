<section class="blog" id="blog">
  <div class="main-text">
    <h2 class="heading">My Projects</h2>
    <span>MY Latest New & Popular Projects</span>
  </div>

  <div class="blog-box swiper mySwiper">
    <div class="cards swiper-wrapper">
      <div class="card swiper-slide">
        <div class="card-top">
          <img src="img/blog/First Project.PNG" alt="imgone" />
        </div>
        <div class="card-info">
          <h2>Word Press Design</h2>
          <span class="date">Client Name: Design Tech Profs</span>
          <p class="excerpt">
            Created By Me With: WordPress, Yoast Seo, Elementor, Etc.
          </p>
          <a href="https://designtechprofs.com/" target="_blank" class="readMore">Project Link</a>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card-top">
          <img src="img/blog/Second Project.PNG" alt="imgtwo" />
        </div>
        <div class="card-info">
          <h2>Custom Website</h2>
          <span class="date">Client Name: Creative Design Tech </span>
          <p class="excerpt">
            Created By Me With HTML , CSS , JAVASCRIPT , Php & Etc.
          </p>
          <a href="https://creativedesigntech.com/" target="_blank" class="readMore">Project Link</a>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card-top">
          <img src="img/blog/third project.PNG" alt="imgthree" />
        </div>
        <div class="card-info">
          <h2>Custom Website</h2>
          <span class="date">Client Name: Marvell Studios </span>
          <p class="excerpt">
            Created By Me With HTML , CSS , JAVASCRIPT , Php & Etc.
          </p>
          <a href="https://marvellstudio.com/" target="_blank" class="readMore">Project Link</a>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card-top">
          <img src="img/blog/five project.PNG" alt="imgfive" />
        </div>
        <div class="card-info">
          <h2>Custom Website</h2>
          <span class="date">Client Name: Infinix Design </span>
          <p class="excerpt">
            Created By Me With HTML , CSS , JAVASCRIPT , Php & Etc.
          </p>
          <a href="https://infinixdesigns.com/" target="_blank" class="readMore">Project Link</a>
        </div>
      </div>

      <div class="card swiper-slide">
        <div class="card-top">
          <img src="img/blog/project-img-8.png" alt="img" />
        </div>
        <div class="card-info">
          <h2>WordPress</h2>
          <span class="date">Client Name: QuickOwlGraphics</span>
          <p class="excerpt">
            Created By Me With: WordPress, Yoast Seo, Elementor, Etc.
          </p>
          <a href="https://quickowlgraphics.com/" target="_blank" class="readMore">Project Link</a>
        </div>
      </div>


    </div>
  </div>

  <div class="swiper-pagination"></div>

  <div class="showcase">
    <img src="shapes/ring.png" class="ring" />
    <img src="shapes/second-circle.png" class="second-circle" />
    <img src="shapes/circle.png" class="circle" />
    <img src="shapes/half-ring.png" class="half-ring" />
  </div>
</section>