<section class="portfolio" id="portfolio">
  <div class="main-text">
    <h2 class="heading">My Services</h2>
    <span>what i will do for you</span>
  </div>
  <div class="fillter-buttons">
    <button class="button mixitup-control-active" data-filter="all">
      All Work
    </button>
    <button class="button" data-filter=".web">Frontend Design</button>
    <button class="button" data-filter=".uiux">Backend Development</button>
    <button class="button" data-filter=".branding">Word Press</button>
  </div>

  <div class="portfolio-gallery">

    <div class="portfolio-box mix uiux">

      <div class="portfolio-content">
        <h3>Backend development</h3>
        <p>
          Backend development refers to the server-side aspect of web development
        </p>
        <a href="#blog" class="readMore">Explore More</a>
      </div>
      <div class="portfolio-img">
        <img src="img/portfolio/1.jpg" alt="img" />
      </div>
    </div>

    <!-- frontend start here  -->
    <div class="portfolio-box mix web">
      <div class="portfolio-content">
        <h3>Custom Design</h3>
        <p>
          Custom Web Design: Creating unique, responsive, and
          mobile-friendly websites that reflect clients' brand identities.
        </p>
        <a href="#blog" class="readMore">Explore More</a>
      </div>
      <div class="portfolio-img">
        <img src="img/portfolio/4.jpg" alt="img" />
      </div>
    </div>

    <div class="portfolio-box mix web">
      <div class="portfolio-content">
        <h3>Web Optimization</h3>
        <p>
          Website Optimization: Improving website performance, speed, and
          search engine ranking through optimization techniques.
        </p>
        <a href="#blog" class="readMore">Explore More</a>
      </div>
      <div class="portfolio-img">
        <img src="img/portfolio/3.jpg" alt="img" />
      </div>
    </div>

    <!-- frontend end here  -->

    <div class="portfolio-box mix branding">
      <div class="portfolio-content">
        <h3>Word Press</h3>
        <p>
          WordPress Development: Building custom WordPress themes, plugins,
          and solutions that meet clients' specific needs.
        </p>
        <a href="#blog" class="readMore">Explore More</a>
      </div>
      <div class="portfolio-img">
        <img src="img/portfolio/download.jpg" alt="img" />
      </div>
    </div>
    
  </div>
</section>