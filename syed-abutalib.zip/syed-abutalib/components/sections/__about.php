<section class="about" id="about">
  <div class="about-img">
    <img src="img/image.png" alt="img" class="aboutHero" />
    <div class="showcase-ring">
      <img src="shapes/ring.png" class="ring" />
      <img src="shapes/circle.png" class="circle" />
    </div>
  </div>
  <div class="about-content">
    <h2 class="heading">About Me</h2>
    <h3>Hey Im A Full Stack Developer</h3>
    <p>
      I am forever seeking new ways of doing things, learning newer technologies
      every other day.
    </p>
    <div class="about-btn">
      <button class="active">Custom Website</button>
      <button>Mern Stack</button>
      <button>Wordpress</button>
    </div>
    <div class="content-btn">
      <div class="content">
        <div class="text-box">
          <p>For Frontend Development I Use</p>
          <span>HTML5 , CSS3 , ES6 JAVASCRIPT , JQUERY & AJAX , BOOTSTRAP 5 , SCSS , ETC...</span>
        </div>
        <div class="text-box">
          <p>For Backend Development I Use</p>
          <span>PHP , MYSQL , LARAVEL 11 , ETC...</span>
        </div>
        <div class="text-box">
          <p>For Interaction Desing - Animation I Use</p>
          <span>GSAP , LENIS , LOCOMOTIVE , ANIMATE.CSS , ETC...</span>
        </div>
      </div>

      <div class="content">
        <div class="text-box">
          <p>For Frontend Development I Use</p>
          <span>REACT , ANGULAR , NEXT JS , ETC...</span>
        </div>
        <div class="text-box">
          <p>For Backend Development I Use</p>
          <span>LARAVEL 11 , NODE JS , TYPESCRIPT , MONGODB , ETC</span>
        </div>
        <div class="text-box">
          <p>For Interaction Desing - Animation I Use</p>
          <span>GSAP , LENIS , LOCOMOTIVE , ANIMATE.CSS , FRAMER MOTION , ETC...</span>
        </div>
      </div>

      <div class="content">
        <div class="text-box">
          <p>For Page Builder I Use</p>
          <span>Elementor , Astra , Devi And ETC...</span>
        </div>
        <div class="text-box">
          <p>For Seo Wordpress Seo Tools I Use</p>
          <span>Yoast Seo And Much More...</span>
        </div>
        <div class="text-box">
          <p>For Interaction Desing - Animation I Use</p>
          <span>GSAP , LENIS , LOCOMOTIVE , ETC...</span>
        </div>
      </div>
    </div>
    <div class="cvContent">
      <a href="img/Syed Abu Talib.pdf" target="_blank" class="btn d-CV">Download CV <i class="bx bx-download"></i></a>
    </div>
  </div>
</section>