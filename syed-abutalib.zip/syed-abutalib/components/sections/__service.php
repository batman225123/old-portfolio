<section class="services" id="services">
  <div class="main-text">
    <h2 class="heading">My Services</h2>
    <span>what i will do for you</span>
  </div>

  <div class="allServices">
    <div class="servicesItem">
      <div class="icon-services">
        <i class="bx bx-layer"></i>
        <span></span>
      </div>
      <h3>Custom Website</h3>
      <p>
        Your Unique Digital SolutionIn today’s digital landscape.
      </p>
      <a href="#portfolio" class="readMore">Read More</a>
    </div>

    <div class="servicesItem">
      <div class="icon-services">
        <i class="bx bx-code-alt"></i>
        <span></span>
      </div>
      <h3>Mern Stack</h3>
      <p>
        Unlocking Potential with the MERN StackIn the ever-evolving landscape of web development
      </p>
      <a href="#portfolio" class="readMore">Read More</a>
    </div>

    <div class="servicesItem">
      <div class="icon-services">
        <i class="bx bx-desktop"></i>
        <span></span>
      </div>
      <h3>WordPress Development</h3>
      <p>
        WordPress offers a user-friendly and versatile solution to build and manage your online presence.
      </p>
      <a href="#portfolio" class="readMore">Read More</a>
    </div>
  </div>

  <div class="proposal">
    <div class="text-box">
      <span>Get In Touch</span>
      <h3>Have a Project On Your Mind</h3>
      <a href="#contact" class="btn">Contact Me</a>
    </div>
    <img src="img/support.png" class="first" />
  </div>

  <div class="showcase">
    <img src="shapes/ring.png" class="ring" />
    <img src="shapes/circle.png" class="circle" />
    <img src="shapes/circle.png" class="circle2" />
    <img src="shapes/circle.png" class="circle3" />
    <img src="shapes/half-ring.png" class="half-ring" />
  </div>
</section>