<section class="home" id="home">
  <div class="hero-info">
    <h3>Welcome To my Website</h3>
    <h1>Hi I'm Syed Abu-Talib</h1>

    <div class="text-animate">
      <h2>Web Developer</h2>
    </div>

    <p style="font-weight: 800">
      I am a technology enthusiast and developer at heart who love to solve the problems. I started my journey with a
      lot of interest in coding and through the year developed myself into front-end; back end techs. I have many tools
      in my toolbox and even more to learn. I am forever seeking new ways of doing things, learning newer technologies
      every other day.
    </p>
    <div class="btn-box">
      <a href="#contact" class="btn">Contact Me! <i
          class="bx bx-right-arrow-alt"></i></a>
      <a href="img/Syed Abu Talib.pdf" target="_blank" class="btn d-CV">Download CV <i class="bx bx-download"></i></a>
    </div>

    <div class="social-media">
      <div class="bg-icon">
        <a href="#"><i class="bx bxl-youtube"></i></a>
        <span></span>
      </div>

      <div class="bg-icon">
        <a href="#"><i class="bx bxl-github"></i></a>
        <span></span>
      </div>

      <div class="bg-icon">
        <a href="#"><i class="bx bxl-linkedin"></i></a>
        <span></span>
      </div>

      <div class="bg-icon">
        <a href="#"><i class="bx bxl-facebook"></i></a>
        <span></span>
      </div>
    </div>
  </div>
  <div class="img-hero">
    <img src="img/Mineimg.png" alt="img-Hero" />
    <div class="rotate-text">
      <div class="text">
        <p>I'm A Full Stack Developer And I'm A Mern Stack Developer</p>
      </div>
      <span><i></i></span>
    </div>
  </div>
</section>

<!-- for alert  -->
<?php
if (isset($_SESSION['message'])) {
  echo '<div class="alert hide">
        <span class="fas fa-exclamation-circle"></span>
        <span class="msg">✅ ' . $_SESSION['message'] . '</span>
        <div class="close-btn">
          <span class="fas fa-times"></span>
        </div>
      </div>';
  unset($_SESSION['message']);
}
?>