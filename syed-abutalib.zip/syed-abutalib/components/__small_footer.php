<footer>
  <p>
    Copyright © 2024 Made By <span>Syed Abu-Talib</span> || All Right
    Reserved.
  </p>
</footer>

<?php include("__chatbot.php"); ?>