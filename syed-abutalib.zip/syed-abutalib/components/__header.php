<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta title="Syed Abutalib A Full Stack Developer" />
  <title>Syed Abu-Talib Full Stack Developer</title>
  <meta name="description"
    content="I am a technology enthusiast and developer at heart who love to solve the problems. I started my journey with a lot of interest in coding and through the year developed myself into front-end; back end techs. I have many tools in my toolbox and even more to learn. I am forever seeking new ways of doing things, learning newer technologies every other day…">
  <link rel="stylesheet" href="style.css" />
  <!-- boxicon css link -->
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
  <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
</head>

<body>

  <a target="_blank" href="https://wa.me/03160104467" class="whatsapp-button"><i class="fab fa-whatsapp"></i></a>
  <div class="overlay"></div>

  <?php include("__navbar.php"); ?>

  <!-- home section start here  -->
  <?php include("sections/__Home.php"); ?>
  <!-- home section end here  -->

  <!-- about section here start  -->
  <?php include("sections/__about.php"); ?>
  <!-- about section here end  -->

  <!-- service section here start  -->
  <?php include("sections/__service.php"); ?>
  <!-- service section here end  -->

  <!-- portfolio section here start  -->
  <?php include("sections/__portfolio.php"); ?>
  <!-- portfolio section here end  -->

  <!-- myProjects section here start  -->
  <?php include("sections/__myProjects.php"); ?>
  <!-- myProjects section here end  -->

  <!-- contact section here start  -->
  <?php include("sections/__contact.php"); ?>
  <!-- contact section here end  -->