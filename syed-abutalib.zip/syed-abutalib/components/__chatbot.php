<button id="chatbot-toggle-btn">
  <i class="bx bx-message-dots"></i>
</button>

<div class="chatbot-popup" id="chatbot-popup">
  <div class="chat-header">
    <span style="color: #fff">My Assistant</span>
    <button id="close-btn">&times;</button>
  </div>
  <div class="chat-box" id="chat-box"></div>
  <div class="chat-input">
    <input type="text" id="user-input" placeholder="Type a message..." />
    <button id="send-btn">Send</button>
  </div>
  <div class="copyright">
    <a href="index.html" target="_blank">Made By Abu-Talib © 2024</a>
  </div>
</div>