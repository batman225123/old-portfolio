// active hamburger menu
let menuIcon = document.querySelector(".menu-icon");
let navlist = document.querySelector(".navlist");
menuIcon.addEventListener("click", () => {
    menuIcon.classList.toggle("active");
    navlist.classList.toggle("active");
    document.body.classList.toggle("open");
});

// remove navlist
navlist.addEventListener("click", () => {
    navlist.classList.remove("active");
    menuIcon.classList.remove("active");
    document.body.classList.remove("open");
});

// rotate text js code
let text = document.querySelector(".text p");

text.innerHTML = text.innerHTML
    .split("")
    .map((char, i) => `<b style="transform:rotate(${i * 6.3}deg")>${char}</b>`)
    .join("");

// switch between about buttons

const buttons = document.querySelectorAll(".about-btn button");
const contents = document.querySelectorAll(".content");

buttons.forEach((button, index) => {
    button.addEventListener("click", () => {
        contents.forEach((content) => (content.style.display = "none"));
        contents[index].style.display = "block";
        buttons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");
    });
});

// portfolio fillter

var mixer = mixitup(".portfolio-gallery", {
    selectors: {
        target: ".portfolio-box",
    },
    animation: {
        duration: 500,
    },
});

// Initialize swiperjs

var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    autoplay: {
        delay: 3000,
        disableOnInteraction: false,
    },

    breakpoints: {
        576: {
            slidesPerView: 2,
            spaceBetween: 10,
        },
        1200: {
            slidesPerView: 3,
            spaceBetween: 20,
        },
    },
});

//   skill Progress bar

const first_skill = document.querySelector(".skill:first-child");
const sk_counters = document.querySelectorAll(".counter span");
const progress_bars = document.querySelectorAll(".skills svg circle");

window.addEventListener("scroll", () => {
    if (!skillsPlayed) skillsCounter();
});

function hasReached(el) {
    let topPosition = el.getBoundingClientRect().top;
    if (window.innerHeight >= topPosition + el.offsetHeight) return true;
    return false;
}

function updateCount(num, maxNum) {
    let currentNum = +num.innerText;

    if (currentNum < maxNum) {
        num.innerText = currentNum + 1;
        setTimeout(() => {
            updateCount(num, maxNum);
        }, 12);
    }
}

let skillsPlayed = false;

function skillsCounter() {
    if (!hasReached(first_skill)) return;
    skillsPlayed = true;
    sk_counters.forEach((counter, i) => {
        let target = +counter.dataset.target;
        let strokeValue = 465 - 465 * (target / 100);

        progress_bars[i].style.setProperty("--target", strokeValue);

        setTimeout(() => {
            updateCount(counter, target);
        }, 400);
    });

    progress_bars.forEach(
        (p) => (p.style.animation = "progress 2s ease-in-out forwards")
    );
}

// side progress bar

let calcScrollValue = () => {
    let scrollProgress = document.getElementById("progress");
    let pos = document.documentElement.scrollTop;

    let calcHeight =
        document.documentElement.scrollHeight -
        document.documentElement.clientHeight;
    let scrollValue = Math.round((pos * 100) / calcHeight);

    if (pos > 100) {
        scrollProgress.style.display = "grid";
    } else {
        scrollProgress.style.display = "none";
    }

    scrollProgress.addEventListener("click", () => {
        document.documentElement.scrollTop = 0;
    });

    scrollProgress.style.background = `conic-gradient(#fff ${scrollValue}%,#e6006d ${scrollValue}%)`;
};

window.onscroll = calcScrollValue;
window.onload = calcScrollValue;

// active menu

let menuLi = document.querySelectorAll("header ul li a");
let section = document.querySelectorAll("section");

function activeMenu() {
    let len = section.length;
    while (--len && window.scrollY + 97 < section[len].offsetTop) { }
    menuLi.forEach((sec) => sec.classList.remove("active"));
    menuLi[len].classList.add("active");
}
activeMenu();
window.addEventListener("scroll", activeMenu);

// scroll reveal

ScrollReveal({
    distance: "50px",
    duration: 2000,
    delay: 100,
    // reset: true ,
});

//  Chat Bot Javascript 
const responses = {
    hi: "Hi there! How can I assist you today?",
    hello: "Hi there! How can I assist you today?",
    yes: "You Can Ask Me Anything, Try To Ask Me?",
    yeah: "You Can Ask Me Anything, Try To Ask Me?",
    "good morning": "Hey There ",
    "how are you": "Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "how are u": "Im Just A Bot But You Can Ask Me Anything, Try To Ask Me?",
    "im fine": "Thats Good To Hear From You",
    "what about you": "Im Just A Bot But You Can Ask Me Anything, Try To Ask Me?",
    "what about u": "Im Just A Bot But You Can Ask Me Anything, Try To Ask Me?",
    "lets chat": "Hey There ",
    "who are you": "Im Just A Bot ",
    "good night": "May your night pass peacefully, and may you have a refreshing start tomorrow",
    "who is abutalib":
        "Abutalib is a great coder and his coding skill is very good and he is also a Frontend Developer & If you want to approach him then visit one of his best created website this is the link of his created website .<a href='https://creativedesigntech.com/' target='_blank'>Visit Website</a>",
    "who create this site": "this website is created by syed abutalib his a frontend developer",
    "who create this website": "this website is created by syed abutalib his a frontend developer",
    "who create you": "this Chatbot is created by syed Abutalib",
    "who create this": "this Chatbot is created by syed Abutalib",
    "ok then who create you": "this Chatbot is created by syed Abutalib",
    "ok then who created you": "this Chatbot is created by syed Abutalib",
    "ok then who are you": "Im Just A Bot But You Can Ask Me Anything, Try To Ask Me?",
    "who created you": "this Chatbot is created by syed Abutalib",
    "need help": "How I can help you today?",
    "i need help": "How I can help you today?",
    bye: "Goodbye! Have a great day!",
    default: "I'm sorry, I didn't understand that. Want to connect with expert?",
    expert: "Great! Please wait a moment while we connect you with an expert.",
    no: "Okay, if you change your mind just let me know!",
    not: "Okay, if you change your mind just let me know!",
    ok: "You Can Ask Me Anything, Try To Ask Me?",
    okay: "You Can Ask Me Anything, Try To Ask Me?",
    then: "You Can Ask Me Anything, Try To Ask Me?",
    "are you okay": "Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you ok": "Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you fine": "Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "then ok": "sorry i cant understand",
    "ok then": "sorry i cant understand",
    "ok then who are you": "Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "im sorry": "Its ok Everyone Make mistake",
    "sorry": "Its ok Everyone Make mistake",
    "ok then help me": "I can help you but can u tell me more about it that what are you asking for",
    "ok then help": "I can help you but can u tell me more about it that what are you asking for",
    "can you help me": "I can help you but can u tell me more about it that what are you asking for",
    "can you help": "I can help you but can u tell me more about it that what are you asking for",
    "help me": "I can help you but can u tell me more about it that what are you asking for",
    "you need help": "Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you a chatbot": "Yes Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you a chat bot": "Yes Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you a bot": "Yes Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you chatbot": "Yes Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you chat bot": "Yes Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "are you bot": "Yes Im Just A Bot And You Can Ask Me Anything, Try To Ask Me?",
    "nice to meet you": "it's a pleasure to meet you, Try To Ask Me?",
    "nice to meet u": "it's a pleasure to meet you, Try To Ask Me?",
    "its nice to meet you": "it's a pleasure to meet you, Try To Ask Me?",
    "ok then tell me more about you": "Im Just A Bot But You Can Ask Me Anything, Try To Ask Me?",
    "can you tell me more about you": "Im Just A Bot But You Can Ask Me Anything, Try To Ask Me?",
    so: "sorry i cant understand im just a bot try to ask me something else",
    "tell me a joke": "what kind of joke are you asking for",
    "im angry": "anger is not good for your health so treasure yourself",
    "im happy": "its good to hear from you",
    "i dont need": "Okay, if you change your mind just let me know!",
    "i dont need help": "Okay, if you change your mind just let me know!",
    "we need help": "what kind of help are you asking for",
};

document
    .getElementById("chatbot-toggle-btn")
    .addEventListener("click", toggleChatbot);
document.getElementById("close-btn").addEventListener("click", toggleChatbot);
document.getElementById("send-btn").addEventListener("click", sendMessage);
document
    .getElementById("user-input")
    .addEventListener("keypress", function (e) {
        if (e.key === "Enter") {
            sendMessage();
        }
    });

function toggleChatbot() {
    const chatbotPopup = document.getElementById("chatbot-popup");
    chatbotPopup.style.display =
        chatbotPopup.style.display === "none" ? "block" : "none";
}

function sendMessage() {
    const userInput = document.getElementById("user-input").value.trim();
    if (userInput !== "") {
        appendMessage("user", userInput);
        respondToUser(userInput.toLowerCase());
        document.getElementById("user-input").value = "";
    }
}

function respondToUser(userInput) {
    const response = responses[userInput] || responses["default"];
    setTimeout(function () {
        appendMessage("bot", response);
    }, 500);
}

function appendMessage(sender, message) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("div");
    messageElement.classList.add(
        sender === "user" ? "user-message" : "bot-message"
    );
    messageElement.innerHTML = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
    if (sender === "bot" && message === responses["default"]) {
        const buttonYes = document.createElement("button");
        buttonYes.textContent = "✔ Yes";
        buttonYes.onclick = function () {
            appendMessage("bot", responses["expert"]);
        };
        const buttonNo = document.createElement("button");
        buttonNo.textContent = "✖ No";
        buttonNo.onclick = function () {
            appendMessage("bot", responses["no"]);
        };
        const buttonContainer = document.createElement("div");
        buttonContainer.classList.add("button-container");
        buttonContainer.appendChild(buttonYes);
        buttonContainer.appendChild(buttonNo);
        chatBox.appendChild(buttonContainer);
    }
}

// chat bot javascript end /*

ScrollReveal().reveal(".hero-info,.main-text,.proposal,.heading", {
    origin: "top",
});
ScrollReveal().reveal(".about-img,.fillter-buttons", {
    origin: "left",
});
ScrollReveal().reveal(".about-content,.skills", { origin: "right" });
ScrollReveal().reveal(
    ".allServices,.portfolio-gallery,.img-hero",
    { origin: "bottom" }
);
