<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


if (isset($_POST['submit'])) {
  $name = $_POST['first_name'];
  $last_name = $_POST['last_name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $message = $_POST['message'];

  //Create an instance; passing `true` enables exceptions
  $mail = new PHPMailer(true);

  try {
    //Server settings
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'baaliawg@gmail.com';                     //SMTP username
    $mail->Password   = 'cpakyqwqtomuokds';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom($email, $name);
    $mail->addAddress('baaliawg@gmail.com', 'Hey Syed Abutalib You Got A Message From Your Website');               //Name is optional

    //Content
    $mail->isHTML(true);
    $mail->Subject = 'Hey Syed Abutalib You Got A New Client Message From Your Personal Website';
    $mail->Body    =
      'First Name: ' . $name . ' <br/><br/>
      Last Name: ' . $last_name . ' <br/><br/>
      Email: ' . $email . ' <br/><br/>
      Phone: ' . $phone . ' <br/><br/>
      Message: ' . $message . '
    ';

    $mail->send();
    $_SESSION['message'] = 'Form Submitted Successfully! Thank You';
    header("Location: index.php");
  } catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }
} else {
  $_SESSION['message'] = 'Server Down! Please Try Again Later';
  header("Location: index.php");
}
